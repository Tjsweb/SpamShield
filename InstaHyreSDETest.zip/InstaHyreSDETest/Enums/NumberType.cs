﻿namespace InstaHyreSDETest.Enums
{
    public class NumberType
    {
        public enum NumberTypeEnum
        {
            Normal,
            Spam
        }
    }
}
