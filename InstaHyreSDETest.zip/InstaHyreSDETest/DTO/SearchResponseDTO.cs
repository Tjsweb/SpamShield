﻿namespace InstaHyreSDETest.DTO
{
    public class SearchResponseDTO
    {
        public string PhoneNumber { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public bool isSpam { get; set; }
    }
}
